#!/usr/bin/env bash
# missing argument handling / wrong output
cat "$1" | wc -c
