#!/usr/bin/env bash
wc -l < "$1" | xargs
