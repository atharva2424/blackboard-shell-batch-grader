#!/usr/bin/env bash
# incorrect: prints lines+1
lines=$(wc -l < "$1"); echo $((lines + 1))
